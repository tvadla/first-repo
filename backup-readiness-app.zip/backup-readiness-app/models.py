from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class System(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    last_backup = db.Column(db.Date)
    success_rate = db.Column(db.Float)
    last_test = db.Column(db.Date)
    owner = db.Column(db.String(100))
    status = db.Column(db.String(50))

    def __repr__(self):
        return f"<System {self.name}>"