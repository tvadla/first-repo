print("APP STARTING...")

from flask import Flask, render_template, request, redirect, send_file, jsonify
from datetime import datetime
import pandas as pd
import csv
import os

from models import db, System
from rules import classify_system

# --- AI imports ---
from langchain_openai import ChatOpenAI
import httpx

# -------------------- FLASK SETUP --------------------

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///systems.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

with app.app_context():
    db.create_all()

# -------------------- AI SETUP --------------------

API_KEY = os.getenv("API_KEY")

client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-gpt-4.1",
    api_key=API_KEY,
    http_client=client,
    temperature=0.3
)

# -------------------- HOME --------------------

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        try:
            name = request.form["name"]
            last_backup = datetime.strptime(request.form["last_backup"], "%Y-%m-%d").date()
            success_rate = float(request.form["success_rate"])
            last_test = datetime.strptime(request.form["last_test"], "%Y-%m-%d").date()
            owner = request.form["owner"]

            status = classify_system(last_backup, success_rate)

            system = System(
                name=name,
                last_backup=last_backup,
                success_rate=success_rate,
                last_test=last_test,
                owner=owner,
                status=status
            )

            db.session.add(system)
            db.session.commit()

            return redirect("/dashboard")

        except Exception as e:
            return f"Error: {str(e)}"

    return render_template("index.html")


# -------------------- DASHBOARD --------------------

@app.route("/dashboard")
def dashboard():
    systems = System.query.all()
    today = datetime.today().date()

    for s in systems:
        s.backup_age = (today - s.last_backup).days

    ready = sum(1 for s in systems if s.status == "Ready")
    at_risk = sum(1 for s in systems if s.status == "At-Risk")
    critical = sum(1 for s in systems if s.status == "Critical")

    return render_template(
        "dashboard.html",
        systems=systems,
        ready=ready,
        at_risk=at_risk,
        critical=critical
    )


# -------------------- EXPORT CSV --------------------

@app.route("/export")
def export():
    systems = System.query.all()

    data = [{
        "Name": s.name,
        "Last Backup": s.last_backup,
        "Success Rate": s.success_rate,
        "Last Test": s.last_test,
        "Owner": s.owner,
        "Status": s.status
    } for s in systems]

    df = pd.DataFrame(data)
    file_path = "report.csv"
    df.to_csv(file_path, index=False)

    return send_file(file_path, as_attachment=True)


# -------------------- UPLOAD CSV --------------------

@app.route("/upload", methods=["POST"])
def upload():
    file = request.files.get("file")

    if not file:
        return "No file uploaded"

    try:
        reader = csv.DictReader(file.stream.read().decode("utf-8").splitlines())

        for row in reader:
            last_backup = datetime.strptime(row["last_backup"], "%Y-%m-%d").date()
            last_test = datetime.strptime(row["last_test"], "%Y-%m-%d").date()
            success_rate = float(row["success_rate"])

            status = classify_system(last_backup, success_rate)

            system = System(
                name=row["name"],
                last_backup=last_backup,
                success_rate=success_rate,
                last_test=last_test,
                owner=row["owner"],
                status=status
            )

            db.session.add(system)

        db.session.commit()

        return redirect("/dashboard")

    except Exception as e:
        return f"Upload Error: {str(e)}"


# -------------------- AI ENDPOINT --------------------

@app.route("/ai")
def ai():
    name = request.args.get("name")
    age = request.args.get("age")
    success = request.args.get("success")
    status = request.args.get("status")

    prompt = f"""
    You are an expert in IT infrastructure resilience.

    System: {name}
    Backup Age: {age} days
    Success Rate: {success}
    Status: {status}

    Provide:
    - Root cause
    - Risk level
    - Clear remediation steps

    Keep it short and practical.
    """

    try:
        response = llm.invoke(prompt)
        return jsonify({"response": response.content})

    except Exception as e:
        print("AI ERROR:", e)

        return jsonify({
            "response": f"⚠️ Fallback: Backup age is {age} days. Improve backup frequency and reliability."
        })


# -------------------- MAIN --------------------

if __name__ == "__main__":
    print("Starting Flask server...")
    app.run(debug=True, host="0.0.0.0", port=5000)