from datetime import datetime

def classify_system(last_backup, success_rate):
    today = datetime.today().date()
    backup_age = (today - last_backup).days

    # READY
    if backup_age <= 10 and success_rate >= 81:
        return "Ready"

    # AT-RISK
    elif backup_age <= 30 and 60 <= success_rate < 81:
        return "At-Risk"

    # CRITICAL
    else:
        return "Critical"